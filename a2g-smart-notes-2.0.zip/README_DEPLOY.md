## Deployment notes

1. Add `.env.local` variables from `.env.example` in Firebase Console (or local .env.local).
2. Connect repo to Firebase Hosting and enable GitHub Action deploy or use `firebase deploy`.
3. For Firebase Hosting with Next.js, follow official guide to enable SSR/static pages.
