'use client';
import { useState } from 'react';

export default function AdminNotes() {
  const [title, setTitle] = useState('');
  const [file, setFile] = useState(null);

  const upload = async (e) => {
    e.preventDefault();
    alert('Implement upload to Firebase Storage and Firestore metadata.');
  }

  return (
    <main className="min-h-screen p-8">
      <h1 className="text-2xl font-bold">Admin - Upload Notes</h1>
      <form onSubmit={upload} className="mt-4 space-y-3">
        <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Title" className="border p-2 w-full" />
        <input type="file" onChange={e=>setFile(e.target.files?.[0] || null)} />
        <button className="bg-green-600 text-white px-4 py-2">Upload</button>
      </form>
    </main>
  )
}
