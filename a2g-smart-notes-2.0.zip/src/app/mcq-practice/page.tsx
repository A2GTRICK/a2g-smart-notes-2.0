export default function McqPractice() {
  return (
    <main className="min-h-screen p-8">
      <h1 className="text-2xl font-bold">MCQ Practice</h1>
      <p className="mt-4">Add MCQ questions in Firestore and render here.</p>
    </main>
  )
}
