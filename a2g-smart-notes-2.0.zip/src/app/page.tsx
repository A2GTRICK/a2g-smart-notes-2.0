import Link from 'next/link';

export default function Home() {
  return (
    <main className="min-h-screen p-8">
      <h1 className="text-3xl font-bold">A2G Smart Notes 2.0</h1>
      <p className="mt-4">Welcome — starter scaffold installed.</p>
      <nav className="mt-6 space-x-4">
        <Link href="/login">Login</Link>
        <Link href="/dashboard">Dashboard</Link>
        <Link href="/admin/notes">Admin - Notes</Link>
        <Link href="/mcq-practice">MCQ Practice</Link>
      </nav>
    </main>
  )
}
